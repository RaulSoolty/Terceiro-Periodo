<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FornecedorController extends Controller
{
    public function index(){
        $fornecedores = [

        0 => [
            'nome' => 'Fornecedor 1',
            'status' => 'N',
            'cnpj' => '00.000.000.0000-00',
            'DDD' => '062',
            'telefone' => '98877-6655'
        ],
        1 => [
            'nome' => 'Fornecedor 2',
            'status' => 'S',
            'cnpj' => null,
            'DDD' => '061',
            'telefone' => '98877-6655'
        ],
        2 => [
            'nome' => 'Fornecedor 3',
            'status' => 'N',
            'cnpj' => null,
            'DDD' => '064',
            'telefone' => '98877-6655'
        ],
        3 => [
            'nome' => 'Fornecedor 4',
            'status' => 'S',
            'cnpj' => null,
            'DDD' => '032',
            'telefone' => '98877-6655'
        ]
    ]; 

    


        return view('app.fornecedor.index', compact('fornecedores'));
    }
}
