<h3>Contato (view)</h3>

<ul>    
    <li>
        <a href="<?php echo e(route('site.index')); ?>">Principal</a>
    </li>
    <li>
    <a href="<?php echo e(route('site.sobrenos')); ?>">Sobre Nós</a>  
    </li>
    <li>
    <a href="<?php echo e(route('site.contato')); ?>">Contato</a>
    </li>
</ul>    <?php /**PATH C:\Users\grifo\Documents\WorkSpace\Code\app_super_gestao\resources\views/site/contato.blade.php ENDPATH**/ ?>