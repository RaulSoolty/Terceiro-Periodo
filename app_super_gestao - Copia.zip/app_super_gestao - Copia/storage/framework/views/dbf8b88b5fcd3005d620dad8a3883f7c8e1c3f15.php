
P1 = <?php echo e($p1); ?>

<br />
P2 = <?php echo e($p2); ?><?php /**PATH C:\Users\grifo\Documents\WorkSpace\Code\app_super_gestao\resources\views/site/teste.blade.php ENDPATH**/ ?>