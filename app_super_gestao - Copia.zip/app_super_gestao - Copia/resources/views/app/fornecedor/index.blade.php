<h3>Fornecedor</h3>


@php
/*
@if(count($fornecedores) > 0 && count($fornecedores) < 10)
    <h3> Existem alguns fornecedores cadastrados</h3>
@elseif(count($fornecedores) > 10)
    <h3>Existem varios fornecedores cadastrados</h3>
@else
    <h3>Ainda não existem fornecedores cadastrados!</h3>
@endif  */

/*  @if( $fornecedores[0]['status'] == 'N' )
    Fornecedor inativo
@endif 

<br>

@unless($fornecedores [0]['status'] == 'S')
    Fornecedor inativo.
@endunless
<br>  

if(empty{$variavel}) {}  //ele faz com que retorne true se a variavel estiver vazia

vazias quando são lhes atribuidas os seguintes valores. 

''   0   0.0   '0'   null   false   array{}   $var     --< $var = 'xyz' aqui tem atribuição de valor e no exemplos não

 @switch( $fornecedores[0]['DDD'])
            @case ('062')
                Goiânia - GO
                @break
            @case ('032') 
                Belo Horizonte - MG
                @break
            @case ('061')
                Brasilia - DF
                @break
            @case ('064')
                Morrinhos - GO 
                @break
            @default
                Estado não identificado!
        @endswitch

        O for faz com que o $i repita o laço ate a quantidade de forncedores na base
    @for($i =0; isset($fornecedores[$i]); $i++)

        Fornecedor: {{ $fornecedores[$i]['nome'] }}
        <br>
        Status: {{ $fornecedores [$i]['status'] }}
        <br>
        CNPJ: {{ $fornecedores[$i]['cnpj'] ?? 'Dado não preenchido!' }}
        <br>
        telefone({{ $fornecedores[$i]['DDD'] ?? '' }})
                {{ $fornecedores[$i]['telefone'] ?? '' }} 
            <hr>
    @endfor



LOOP  apenas FOREACH ou FORELSE

 */
@endphp


@isset($fornecedores)

    @foreach ($fornecedores as $indice => $fornecedor)

    
        interação atual: {{ $loop->iteration }}
        <br>
        Fornecedor: {{ $fornecedor['nome'] }}
        <br>
        Status: {{ $fornecedor['status'] }}
        <br>
        CNPJ: {{ $fornecedor['cnpj'] ?? 'Dado não preenchido!' }}
        <br>
        telefone({{ $fornecedor['DDD'] ?? '' }})
                {{ $fornecedor['telefone'] ?? '' }} 
        <br>
        @if($loop->first)
            Primeira interação do loop.
            <br>
            Total de Registros {{ $loop->count }}
        @endif
        @if($loop->last)
            Ultima interação do loop.
            
        @endif
        <hr>
    @endforeach
@endisset
