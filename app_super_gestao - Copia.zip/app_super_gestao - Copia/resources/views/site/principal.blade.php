<h3>Principal (view)</h3>
<ul>    
    <li>
        <a href="{{ route('site.index') }}">Principal</a>
    </li>
    <li>
    <a href="{{ route('site.sobrenos') }}">Sobre Nós</a>  
    </li>
    <li>
    <a href="{{ route('site.contato') }}">Contato</a>
    </li>
</ul>    