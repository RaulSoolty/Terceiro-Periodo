<?php

use Illuminate\Support\Facades\Route;



/*
Route::get('/', function () {
    return 'Olá, Seja bem vindo ao curso!';
});
*/

/* verbo http 
get
post
put
patch
delete
options
*/
Route::get('/', 'PrincipalController@principal')->name('site.index');
Route::get('/sobre-nos', 'SobreNosController@sobrenos')->name('site.sobrenos');;
Route::get('/contato', 'ContatoController@contato')->name('site.contato');;
Route::get('/login', function(){return 'login'; })->name('site.login');;

Route::prefix('/app')->group(function ()
{
    Route::get('/clientes', function(){return 'clientes'; })->name('app.clientes');;
    Route::get('/fornecedores', 'FornecedorController@index')->name('app.fornecedores');;
    Route::get('/produtos', function(){return 'produtos'; })->name('app.produtos');;
});

Route::get('/teste/{p1}/{p2}', 'TesteController@teste')->name('teste');



//Rota de fallback -- MSG de erro 404 e tals
Route::fallback(function() {
    echo 'A rota acessada não existe. <a href="/"> Voltar </a>';
});